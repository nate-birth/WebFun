for(var odd = 1; odd <= 20; odd++){
    if(odd % 2 == 1){
        console.log(odd);
    }
}

var sum = 0;
for(var num = 1; num <= 5; num++){
     sum = num+sum;
     console.log("Num: ", num);
     console.log("Sum: ", sum);
}